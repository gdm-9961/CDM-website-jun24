/***************************
*  Graham Meldrum          *
*  CS 0445 - Spring 2024   *
*  PhraseFinder            *
****************************/

import java.util.*;
import java.io.*;

public class PhraseFinder
{
	String oString;
	char[] aString;
	boolean[] placed;
	Node[][] solutions;
	// earliest tracks the first alphabetical unused letter, saving lots of checks deep in recursion
	// spaces tracks the word count of the current phraseOut, and is used as the index to write to solutions
	int earliest, spaces = 0;
	int letCount;
	// note this is one less than the desired word length
	int MIN_WORDSIZE = 2;
	StringBuilder wordOut = new StringBuilder();
	StringBuilder phraseOut = new StringBuilder();
	TrieSTNew dic;
	PrintStream cmdLine = new PrintStream(new FileOutputStream(FileDescriptor.out));
	long timeCheck = System.nanoTime();
	
	public PhraseFinder(String wordIn, TrieSTNew D){
		// import dictionary
		dic = D;
		reset(wordIn);
	} // end constructor
	
	protected void writeSolution() throws IOException{
		// adds current phraseOut to the end of the appropriate linked list 
		solutions[spaces][1] = solutions[spaces][1].next = new Node(phraseOut.toString());
		//cmdLine.println(phraseOut.toString());
	}
	
	// print statements summarize most of this 
	// I'm realizing at 11 PM it would be trivial to allow this to print the results just for a wordcount of N - oh well
							  // thrown exception is for subclass override
	public void printSolutions() throws IOException{
		Node solOut;
		StringBuilder wcOut = new StringBuilder(); 
		StringBuilder wcBlock;
		wcOut.append("Here are the results for '" + oString + "':\n");
		
		int solTot = 0; 
		int solLine = 0;
		for (int wc = 0; wc < solutions.length; wc++){
			solOut = solutions[wc][0].next;
			if (solOut != null){
				solLine = 0;
				wcBlock = new StringBuilder();
				while (solOut != null){
					wcBlock.append(solOut.data + "\n");
					solOut = solOut.next;
					solLine++;
				}
				wcOut.append("There were " + solLine + " " + (wc + 1) + "-word solutions:\n" + wcBlock.toString());
				solTot += solLine;
			}
		}
		wcOut.append("There were a total of " + solTot + " solutions");
		System.out.println(wcOut.toString());
	}
	
	public void findPhrases() throws IOException{
		cmdLine.print(oString + " - ");
		findPhrases(letCount);
	}
	
	protected void findPhrases(int letLeft) throws IOException{
		int letCheck = nextValLet(earliest);
		// nextValLet returns the word length as a fail state
		while (letCheck < letCount){
			if (letCheck == earliest) earliest++;
			wordOut.append(aString[letCheck]);
			if (letLeft == letCount) cmdLine.print(wordOut);
			placed[letCheck] = true;
			int search = dic.searchPrefix(wordOut.toString());

		 // if found (in any form)
			if (!(search == 0)) {
				// if complete word (handled before prefixes in order to maintain alphabetical order)
				if (search > 1 && wordOut.length() > MIN_WORDSIZE){
					// adding wordOut (search key) to phraseOut (prospective solution)
					phraseOut.append(wordOut.toString());
				    // if this is the last letter to solve for
					if (letLeft == 1){ 
						writeSolution();
						phraseOut.delete(phraseOut.length() - wordOut.length(),phraseOut.length());
					}
					else {
						// add space and increment wordcount
						phraseOut.append(" ");
						spaces++;
						
						// recurse with fresh wordOut SB
						char[] holdWord = new char[wordOut.length()];
						wordOut.getChars(0,wordOut.length(),holdWord,0);
						wordOut = new StringBuilder();
						
						findPhrases(letLeft-1);
						
						// on return, remove space and decrement wordcount
						phraseOut.deleteCharAt(phraseOut.length() - 1);
						spaces--;
						
						// restore wordOut and phraseOut
						wordOut = new StringBuilder(String.valueOf(holdWord));
						phraseOut.delete(phraseOut.length() - holdWord.length, phraseOut.length());
					}
				}
			 // if prefix and not the last letter to be placed, recurse
                           // otherwise obviously it's a dead end			 
				if ((search % 2 == 1) && letLeft > 1) findPhrases(letLeft-1);
			}
			// backspace
			wordOut.deleteCharAt(wordOut.length() - 1);
			placed[letCheck] = false;
			// mark the spot as open again if necessary
			if (letCheck < earliest) earliest = letCheck;
			// try the next available letter
			letCheck = nextValLet(letCheck + 1);
		}
		if (letLeft == letCount) cmdLine.println(" - " + (((double)(System.nanoTime() - timeCheck))/1000000000) + "s");
	}
	
	private int nextValLet(int tryLet){ // next valid letter
		if (tryLet < letCount){
			//  letter is already placed, or is a repeat of the previous letter
			if (placed[tryLet] || (tryLet > 0 && (aString[tryLet-1] == aString[tryLet] && !placed[tryLet-1]))) tryLet = nextValLet(tryLet + 1);
		}
		if (tryLet == earliest) earliest++;
		return tryLet;
	}
	
	public void reset(String newWord){
		// remember input phrase
		oString = newWord;
		
		// alphabetize phrase, remove whitespace - every solution found by this class will a sorted as it's recorded, without any need for comparisons
		aString = oString.toCharArray();
		Arrays.sort(aString);
		int d;
		for (int r = 0; r < aString.length; r++){
			if (aString[r] > '@' && aString[r] < '['){
				for (int c = r; c < aString.length && aString[c] < '['; c++) aString[c] = (char)(aString[c] + ('a' - 'A'));
				Arrays.sort(aString);
			}
			if (aString[r] > '`' && aString[r] <  '{'){          
				d = r;
				while (++d < aString.length){
					if (aString[d] > 'z') break;
				}													// method uses exclusive index
				if (r > 0 || d < aString.length) aString = Arrays.copyOfRange(aString, r, aString.length);
				break;
			}
		}
		letCount = aString.length;
		
		// generate static bool array of aString length
		placed = new boolean[letCount];
		
		// 2D array of singly-linked, null-terminated lists [firstNode,lastNode] to separate by word count
		solutions = new Node[MIN_WORDSIZE > 0 ? letCount / MIN_WORDSIZE : letCount][2];
		// unfortunately, in theory our input string could be "aaaaaaaa" - so we must assume the word count can be the same as the phrase length
		
		// initializing everything with a placeholder Node that we'll skip on print - this adds significant overhead (as does the array itself) for phrases with few solutions, or invariable wordcounts, but it saves us a check for the special case of a null index every time we add a Node to these lists
		for (Node[] s : solutions) s[0] = s[1] = new Node("");
	}
	
	protected class Node // singly-linked, null-terminated. these are just for temporary storage of solutions
	{
	  protected String data; 	// entry in list
	  protected Node next; 	// link to next node
	  
	  protected Node(String dataPortion){
		 data = dataPortion;
	  } // end constructor
	}
}