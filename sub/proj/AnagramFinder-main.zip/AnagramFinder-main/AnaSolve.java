/***************************
*  Graham Meldrum          *
*  April 2024              *
*  Anagram Solver          *
***************************/

import java.util.*;
import java.io.*;

public class AnaSolve
{ 
	public static void main(String[] args) throws IOException {
		if (args.length < 2) throw new IOException("Insufficient arguments. Please specify at least one input file and exactly one output file. Be aware existing files will be overwritten by the output.");
		else {
			// used for testing runtime, obviously
			double runtime = (double)System.nanoTime();
			
			// input streams/objs
			Scanner keywords;
			TrieSTNew dic = generateDic();
			
			// output streams/objs
			PhraseFinder nextPhrase;
			PrintStream original = System.out;
			boolean perPhrase = false;
			if (args[args.length - 1].equals("-m")){
				perPhrase = true;
			}
			else System.setOut(new PrintStream(new File(args[args.length-1])));
			
			// allow multiple input files
			int count = 0;
			if (perPhrase) new File ("./output").mkdirs();
			for (int k = 0; k < args.length - 1; k++){
				if (args[k].contains(".txt")){
					// all args except last (output file)
					keywords = new Scanner(new FileInputStream(args[k]));
					original.println("\n" + args[k]);
					if (!perPhrase) System.out.println(args[k] + "\n");
					
					// process and append solutions for each phrase
					while (keywords.hasNext()){
						count++;
						String inPhrase = keywords.nextLine(); 
						if (perPhrase) System.setOut(new PrintStream(new File("./output/" + inPhrase + ".txt")));
						nextPhrase = inPhrase.length() > 9 ? new PhraseFinderXL(inPhrase,dic) : new PhraseFinder(inPhrase,dic);
						nextPhrase.findPhrases();
						nextPhrase.printSolutions();
						System.out.println();
					}
					original.println();
				}
				else {
					count++;
					if (perPhrase) System.setOut(new PrintStream(new File("./output/" + args[k] + ".txt")));
					else System.out.println(args[k] + "\n");
					nextPhrase = args[k].length() > 9 ? new PhraseFinderXL(args[k],dic) : new PhraseFinder(args[k],dic);
					nextPhrase.findPhrases();
					nextPhrase.printSolutions();
					System.out.println();
				}
				// extra space after end of file for readability
				System.out.println();
			}
			// printing runtime and brief log to command line
			runtime = (((double)System.nanoTime()) - runtime) / 1000000000;
			System.setOut(original);
			System.out.println("\nAll anagrams for " + count + " phrase(s) in " + (args.length - 1) + " input(s) solved in " + runtime + " seconds\nSee " + (perPhrase ? "output files" : args[args.length-1]) + " for solutions and details\n\nIf you're having trouble opening a file, " + (perPhrase ? "" : "try printing each phrase to its own file by entering '-m' for the output filepath, or ") + "consult Stack Overflow threads #159521 & #102829");
		}
	}
	
	// only called once in this program (same object is passed as arg to all PhraseFinder objects), but in theory can be called by PhraseFinder class if no dictionary is provided
	public static TrieSTNew generateDic() throws IOException {
		Scanner fileScan = new Scanner(new FileInputStream("dictionary.txt"));
		String dicIn;
		TrieSTNew D = new TrieSTNew();
		
		while (fileScan.hasNext()){
			dicIn = fileScan.nextLine();
			D.put(dicIn,dicIn);
		}
		return D;
	}
}