/***************************
*  Graham Meldrum          *
*  CS 0445 - Spring 2024   *
*  PhraseFinderXL          *
****************************/

import java.util.*;
import java.io.*;


// WARNING: For your own safety, do not feed large Strings into this. 
// The problem isn't that the program won't run - the problem is that it *will*.
public class PhraseFinderXL extends PhraseFinder
{
	long[] outCount;
	int CHUNK_SIZE;
	// global so we can delete the folder on close
	File tempFol;
	
	public PhraseFinderXL(String wordIn, TrieSTNew D){
		super(wordIn,D);
		// especially long strings may actually necessitate using a long rather than an int here
		outCount = new long[solutions.length];
		// just under Java's default max heap size
		CHUNK_SIZE = 500000000 / (solutions.length * solutions.length) * 2;
		// I was running into issues with doing the below in a way that looks less stupid
		new File ("./temp" + timeCheck).mkdirs();
		tempFol = new File ("./temp" + timeCheck);
	}
	
	protected void writeSolution() throws IOException{
		solutions[spaces][1] = solutions[spaces][1].next = new Node(phraseOut.toString());
		//[for testing or monitoring] cmdLine.println(phraseOut.toString());
		outCount[spaces]++;
		
		// a linked list is long enough we want to print out to a temp file and clear it from RAM/the heap
		if (outCount[spaces] % CHUNK_SIZE == 0){
			PrintStream defaultP = System.out;
			// save it in such a way that we can recall it in order later *and* avoid collisions between, say, 1 14 and 11 4
			PrintStream outNew = new PrintStream(new File("./temp" + timeCheck + "/" + oString + "-" + spaces + "-" + (outCount[spaces] / CHUNK_SIZE) + "-" + CHUNK_SIZE + ".txt"));
			System.setOut(outNew);
			// this is essentially the same as the regular printSolutions algorithm
			Node save = solutions[spaces][0].next;
			while (save != null){
				System.out.println(save.data);
				save = save.next;
			}
			System.setOut(defaultP);
			// my understanding would be that a PrintStream object initialized in here should be decommissioned on exit 
			// but I always read people saying a formal close() is best practice
			outNew.close();
			solutions[spaces][1] = solutions[spaces][0];
			solutions[spaces][0].next = null;
		}
	}
	
	public void printSolutions(PrintStream outFile, boolean burn) throws IOException{
		Node solOut;
		outFile.println("Here are the results for '" + oString + "':\n");
		
		int solTot = 0;
		for (int wc = 0; wc < solutions.length; wc++){
			Scanner fileScan;
			if (outCount[wc] > 0){
				outFile.println("There were " + outCount[wc] + " " + (wc + 1) + "-word solutions:");
				if (outCount[wc] > CHUNK_SIZE - 1){
					for (int fc = 0; fc < (outCount[wc] / CHUNK_SIZE); fc++){
						// read back from each file exactly the same as you would the linked list, then delete it unless the user says not to
						String fileString = new String ("./temp" + timeCheck + "/" + oString + "-" + wc + "-" + (fc+1) + "-" + CHUNK_SIZE + ".txt");
						fileScan = new Scanner(new FileInputStream(fileString));
						while (fileScan.hasNext()) outFile.println(fileScan.nextLine());
						fileScan.close();
						if (burn) new File(fileString).delete();
					}
				}
				solOut = solutions[wc][0].next;
				while (solOut != null){
					outFile.println(solOut.data);
					solOut = solOut.next;
				}
				solTot += outCount[wc];
			}
		}
		outFile.println("There were a total of " + solTot + " solutions");
		if (burn){ 
			close();
		}
	}
	
	public void printSolutions() throws IOException{
		printSolutions(System.out,true);
	}
	
	// especially useful if you don't want to print
	public void close(){
		tempFol.delete();
		reset("");
	}
}